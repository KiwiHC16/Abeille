
<?php

    require_once dirname(__FILE__) . "/../../../../core/php/core.inc.php";
    
?>

<p id="demo">Coucou</p>

<div id="imageDeFond">imageDeFond</div>

<div id="idFiltre">idFiltre</div>

<div id="idFeatures"><p>idFeatures</p></div>

<div id="idRefresh"><p>idRefresh</p></div>

<div id="idUpload"><p>idUpload</p></div>


<?php include_file('desktop', 'networkGraph', 'js', 'Abeille'); ?>
