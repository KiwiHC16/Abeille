<?php
    $in = "/tmp/AbeilleDeamonInput";
    $resourcePath=realpath(dirname(__FILE__).'/../../');
    $WifiLink = "/tmp/zigate";
?>
